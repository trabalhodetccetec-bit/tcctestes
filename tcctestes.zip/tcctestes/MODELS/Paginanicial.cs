﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tcctestes.MODELS
{
    class Paginanicial
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public string CaminhoImagem { get; set; }
        public string planodefundo { get; set; }
    }
}
